package org.example;

import org.example.Dao.BotasDao;
import org.example.Dao.MarcasDao;
import org.example.Dao.impl.BotasDaoImpl;
import org.example.Dao.impl.MarcasDaoImpl;
import org.example.Models.Botas;
import org.example.Models.Marcas;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        MarcasDao marcasDao = new MarcasDaoImpl();
        BotasDao botasDao = new BotasDaoImpl();
        Marcas adidas = new Marcas("adidas", "EEUU");
        marcasDao.guardar(adidas);

        Marcas m = marcasDao.obtenerPorId(adidas.id());
        Botas predator = new Botas(m, "predator", 41, 59.99, 50);
        botasDao.guardar(predator);

        List<Botas> botas = botasDao.obtenerPorMarca(m.id());
        botas.forEach(b -> System.out.println(b.nombre() +  "-" + b.precio()));

    }
}
