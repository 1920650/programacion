package org.example.Dao.impl;

import org.example.Dao.MarcasDao;
import org.example.Models.Marcas;
import org.example.Util.HibernateUtilEjercicio;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class MarcasDaoImpl implements MarcasDao {

    @Override
    public void guardar(Marcas marcas) {
        try (Session s = HibernateUtilEjercicio.getSessionFactory().openSession()) {
            Transaction tx = s.beginTransaction();
            s.persist(marcas);
            tx.commit();
        }
    }

    @Override
    public Marcas obtenerPorId(long id) {
        try (Session s = HibernateUtilEjercicio.getSessionFactory().openSession()) {
            return s.get(Marcas.class, id);
        }
    }

    @Override
    public List<Marcas> obtenerTodas() {
        try (Session s = HibernateUtilEjercicio.getSessionFactory().openSession()) {
            return s.createQuery("FROM Marcas", Marcas.class).list();
        }
    }

    @Override
    public void eliminar(long id) {
        try (Session s = HibernateUtilEjercicio.getSessionFactory().openSession()) {
            Transaction tx = s.beginTransaction();
            Marcas m = s.get(Marcas.class, id);
            if (m != null) s.remove(m);
            tx.commit();
        }
    }
}
