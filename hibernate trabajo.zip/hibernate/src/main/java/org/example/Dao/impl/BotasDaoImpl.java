package org.example.Dao.impl;

import org.example.Dao.BotasDao;
import org.example.Dao.MarcasDao;
import org.example.Models.Botas;
import org.example.Models.Marcas;
import org.example.Util.HibernateUtilEjercicio;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class BotasDaoImpl implements BotasDao{
    public void guardar(Botas botas){
     try(Session s = HibernateUtilEjercicio.getSessionFactory().openSession()){
         Transaction tx = s.beginTransaction();
         s.persist(botas);
         tx.commit();
     }
    }


    public Botas obtenerPorId(long id){
        try(Session s = HibernateUtilEjercicio.getSessionFactory().openSession()){
            return s.get(Botas.class, id);
        }
    }

    public List<Botas> obtenerPorMarca(long marcaId){
        try(Session s = HibernateUtilEjercicio.getSessionFactory().openSession()){
            return s.createQuery("From Botas b where marca.id = :MarcaId", Botas.class)
                    .setParameter("MarcaId", marcaId)
                    .list();
        }
    }

    @Override
    public void actualizarStock(long botaid, int nuevoStock) {
        try(Session s = HibernateUtilEjercicio.getSessionFactory().openSession()){
            Transaction tx = s.beginTransaction();
            Botas botas = s.get(Botas.class, botaid);
            if (botas != null){
                botas.setStock(nuevoStock);
                s.merge(botas);
            }
        }
    }

    public void eliminar(long id){
      try(Session s = HibernateUtilEjercicio.getSessionFactory().openSession()){
          Transaction tx = s.beginTransaction();
          Marcas m = s.get(Marcas.class, id);
          if (m != null) s.remove(m);
          tx.commit();
      }
    }

}
