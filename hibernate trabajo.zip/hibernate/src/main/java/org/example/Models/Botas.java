package org.example.Models;

import jakarta.persistence.*;

@Entity
public class Botas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;
    private double precio;
    private int numeroPie;
    private int stock;

    @ManyToOne
    @JoinColumn(name = "marca_id")
    private Marcas marca;

    public Botas(){

    }

    public Botas(Marcas marca, String nombre, int numeroPie, double precio, int stock) {
        this.marca = marca;
        this.nombre = nombre;
        this.numeroPie = numeroPie;
        this.precio = precio;
        this.stock = stock;
    }

    public Marcas marca() {
        return marca;
    }

    public void setMarca(Marcas marca) {
        this.marca = marca;
    }

    public String nombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double precio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int numeroPie() {
        return numeroPie;
    }

    public void setNumeroPie(int numeroPie) {
        this.numeroPie = numeroPie;
    }

    public int stock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Long id() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
