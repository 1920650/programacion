package org.example.Dao;

import org.example.Models.Botas;
import org.example.Models.Marcas;

import java.util.List;

public interface BotasDao {
    void guardar(Botas botas);
    Botas obtenerPorId(long id);
    List<Botas> obtenerPorMarca(long marcaId);
    void actualizarStock(long Botaid, int nuevoStock);
    void eliminar(long id);

}

