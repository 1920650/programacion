package org.example.Dao;

import org.example.Models.Botas;
import org.example.Models.Marcas;

import java.util.List;

public interface MarcasDao {
    void guardar(Marcas marcas);
    Marcas obtenerPorId(long id);
    List<Marcas> obtenerTodas();
    void eliminar(long id);
}
